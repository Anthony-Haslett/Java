
/**
 * A class to test project objects
 * 
 * @author (Anthony Haslett) 
 * @version (Part 3)
 */
public class Test
{
    public Test()
    {
        /** Shop test*/
        //         Shop shop = new Shop();
        //         shop.readData();
        //         shop.printAllDetailsMap();
        /** Customer test*/   
        Customer customer = new Customer("","Roberts","John","T","Mr");
        Shop shop = new Shop();
        shop.addCustomerMap(customer.getCustomerId(),customer);
        shop.printAllCustomers();
        System.out.println("--- Customer Added to Array \n");
        shop.readCustomerData();
        shop.printAllCustomers();
        /**Doesn't work because of the change to a hashmap, include random id,
           so the id of customers isn't unknown.*/
        shop.writeCustomerData();
    }  
}
